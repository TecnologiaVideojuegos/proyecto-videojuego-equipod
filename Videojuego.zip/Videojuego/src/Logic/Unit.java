package Logic;

import Classes.*;

public class Unit 
{
	private String name;
	private int cost;
	private int damage;
	private int health;
	
	// LAS UNIDADES SE CREAN AL INICIAR LA PARTIDA Y SE METEN AL ARRAY DE CADA JUGADOR
	
	public Unit(String name_unit)
	{
		switch(name_unit)
		{
			case "Contramaestre":
			{
				Contramaestre contramaestre = new Contramaestre();
				this.name = contramaestre.getName();
				this.cost = contramaestre.getCost();
				this.damage = contramaestre.getDamage();
				this.health = contramaestre.getHealth();
			}
		}
	}
	
	// AL CREAR LA UNIDAD SE EJECUTA INITSKILL Y ALIVESKILL PARA COMPROBAR
	// SI ESA CARTA TIENE EFECTOS DE ESOS.
	
	public void initSkill() // Efecto que se ejecuta al invocar la carta.
	{
		switch(name)
		{
			case "Contramaestre":
			{
				
			}
		}
	}
	
	public void attackSkill() // Efecto que se ejecuta al atacar.
	{
		switch(name)
		{
			case "Contramaestre":
			{
				
			}
		}
	}
	
	public void aliveSkill() // Efecto que se ejecuta mientras esta en la mesa.
	{
		switch(name)
		{
			case "Contramaestre":
			{
				
			}
		}
	}
	
	public void deathSkill() // Efecto que se ejecuta al ser destruda la carta.
	{
		switch(name)
		{
			case "Contramaestre":
			{
				
			}
		}
	}
	
	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	public int getCost()
	{
		return cost;
	}
	public void setCost(int cost)
	{
		this.cost = cost;
	}
	public int getDamage()
	{
		return damage;
	}
	public void setDamage(int damage)
	{
		this.damage = damage;
	}
	public int getHealth()
	{
		return health;
	}
	public void setName(int health)
	{
		this.health = health;
	}
}
